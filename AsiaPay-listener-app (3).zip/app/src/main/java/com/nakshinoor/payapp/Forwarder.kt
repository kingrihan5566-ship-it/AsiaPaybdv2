package com.nakshinoor.payapp

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Decides which messages look like "money received", stores them, and posts them to the server. */
object Forwarder {
    private val lock = Any()

    fun prefs(c: Context) = c.getSharedPreferences("pay", Context.MODE_PRIVATE)
    fun url(c: Context) = prefs(c).getString("url", "") ?: ""
    fun key(c: Context) = prefs(c).getString("key", "") ?: ""
    fun configured(c: Context) = url(c).isNotEmpty() && key(c).isNotEmpty()

    private val MONEY = Regex("tk\\.?\\s?\\d|bdt|৳|taka|টাকা|amount")
    private val INCOMING = Regex("received|credited|deposit|cash in|cash-in|money in|incoming|added to|পেয়েছেন|জমা")
    private val TRX = Regex("trx\\s?id|txn\\s?id|transaction\\s?id|trxid|ref(erence)?\\s?(no|id)?")
    private val OUTGOING = Regex("\\b(sent|send money to|paid to|payment to|cash out|cash-out|withdraw|purchase|recharge|bill pay|otp|verification code|your code)\\b")

    /** Returns null when the message should be forwarded, or the reason to skip it. */
    fun skipReason(c: Context, text: String): String? {
        val t = text.lowercase(Locale.ROOT)
        if (!MONEY.containsMatchIn(t)) return "no amount"
        val broad = prefs(c).getBoolean("broad", true)
        val incoming = INCOMING.containsMatchIn(t) || TRX.containsMatchIn(t)
        if (!incoming) return "not a received-money message"
        if (!broad && OUTGOING.containsMatchIn(t) && !INCOMING.containsMatchIn(t)) return "looks like money sent"
        if (OUTGOING.containsMatchIn(t) && !INCOMING.containsMatchIn(t) && !TRX.containsMatchIn(t)) return "looks like money sent"
        return null
    }

    fun log(c: Context, line: String) {
        synchronized(lock) {
            val a = JSONArray(prefs(c).getString("log", "[]"))
            val n = JSONArray(); n.put(java.text.SimpleDateFormat("dd MMM HH:mm:ss", Locale.US).format(java.util.Date()) + "  " + line)
            for (i in 0 until minOf(a.length(), 79)) n.put(a.get(i))
            prefs(c).edit().putString("log", n.toString()).apply()
        }
    }

    /** Adds one message to the send queue. Returns true when it was queued. */
    fun enqueue(c: Context, from: String, text: String, at: Long, force: Boolean = false, quiet: Boolean = false): Boolean {
        val why = skipReason(c, text)
        if (why != null) { if (!quiet) log(c, "Skipped ($why): " + text.replace("\n", " ").take(50)); return false }
        synchronized(lock) {
            val sig = text.trim().hashCode().toString()
            val seen = (prefs(c).getString("seen", "") ?: "").split(",").filter { it.isNotEmpty() }
            if (!force && seen.contains(sig)) return false
            prefs(c).edit().putString("seen", (listOf(sig) + seen).take(400).joinToString(",")).apply()
            val q = JSONArray(prefs(c).getString("queue", "[]"))
            q.put(JSONObject().put("from", from).put("text", text).put("at", at))
            prefs(c).edit().putString("queue", q.toString()).apply()
        }
        return true
    }

    private fun bump(c: Context, k: String) { prefs(c).edit().putInt(k, prefs(c).getInt(k, 0) + 1).apply() }
    /** Called for EVERY notification, so the screen can prove the reader is alive. */
    fun countNotif(c: Context, pkg: String) { bump(c, "nCount"); prefs(c).edit().putString("nPkg", pkg).putLong("nAt", System.currentTimeMillis()).apply() }
    fun countSms(c: Context) { bump(c, "sCount"); prefs(c).edit().putLong("sAt", System.currentTimeMillis()).apply() }

    fun rawAdd(c: Context, src: String, from: String, text: String, verdict: String) {
        synchronized(lock) {
            val a = JSONArray(prefs(c).getString("raw", "[]"))
            val n = JSONArray()
            n.put(JSONObject().put("t", System.currentTimeMillis()).put("s", src).put("f", from.take(40)).put("x", text.replace("\n", " ").take(150)).put("v", verdict))
            for (i in 0 until minOf(a.length(), 39)) n.put(a.get(i))
            prefs(c).edit().putString("raw", n.toString()).apply()
        }
    }

    /** True when the sender filter is empty or the sender matches one of the allowed names. */
    fun senderOk(c: Context, from: String): Boolean {
        val list = (prefs(c).getString("senders", "") ?: "").lowercase(Locale.ROOT).split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (list.isEmpty()) return true
        val f = from.lowercase(Locale.ROOT)
        return list.any { f.contains(it) }
    }

    /** Live message (notification "N" or SMS "S"). */
    fun handle(c: Context, from: String, text: String, src: String = "N") {
        if (prefs(c).getBoolean("paused", false)) { if (MONEY.containsMatchIn(text.lowercase(Locale.ROOT))) rawAdd(c, src, from, text, "skipped: forwarding is paused"); return }
        if (!senderOk(c, from)) { if (MONEY.containsMatchIn(text.lowercase(Locale.ROOT))) rawAdd(c, src, from, text, "skipped: sender not in your list"); return }
        val why = skipReason(c, text)
        if (why != null) {
            if (prefs(c).getBoolean("debug", false) || MONEY.containsMatchIn(text.lowercase(Locale.ROOT))) rawAdd(c, src, from, text, "skipped: $why")
            return
        }
        if (enqueue(c, from, text, System.currentTimeMillis(), quiet = true)) {
            rawAdd(c, src, from, text, "forwarding")
            log(c, "Caught: " + from.take(20).ifEmpty { "?" } + " — " + text.replace("\n", " ").take(40))
            Thread { flush(c) }.start()
        } else rawAdd(c, src, from, text, "already handled")
    }

    /** Sends everything waiting. Returns number still waiting. */
    fun flush(c: Context): Int {
        synchronized(lock) {
            val u = url(c); val k = key(c)
            val q = JSONArray(prefs(c).getString("queue", "[]"))
            if (q.length() == 0) return 0
            if (u.isEmpty() || k.isEmpty()) { log(c, "Sign in or enter the address and key first"); return q.length() }
            val left = JSONArray()
            for (i in 0 until q.length()) {
                val m = q.getJSONObject(i)
                val r = post(u, k, m)
                when {
                    r.first in 200..299 -> { log(c, "Sent OK: " + summary(r.second)); bump(c, "fCount"); record(c, r.second) }
                    r.first == 401 -> { log(c, "Wrong key (401). Sign in again."); left.put(m) }
                    r.first in 400..499 -> log(c, "Server refused (" + r.first + "), dropped")
                    else -> { log(c, "Could not send (" + r.first + "), will retry"); left.put(m) }
                }
            }
            prefs(c).edit().putString("queue", left.toString()).putLong("lastSent", System.currentTimeMillis()).apply()
            if (left.length() > 0) schedule(c)
            return left.length()
        }
    }

    /** Keeps today's totals and the last 20 payments for the home screen, and buzzes once for a new payment. */
    private fun record(c: Context, body: String) {
        try {
            val x = JSONObject(body).optJSONArray("results")?.optJSONObject(0) ?: return
            if (x.optBoolean("ignored") || x.optBoolean("duplicate")) return
            val p = prefs(c); val day = java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(java.util.Date())
            var cnt = p.getInt("dayCount", 0); var amt = p.getLong("dayAmt", 0L)
            if (p.getString("dayKey", "") != day) { cnt = 0; amt = 0L }
            cnt += 1; amt += Math.round(x.optDouble("amount", 0.0) * 100)
            val a = JSONArray(p.getString("recent", "[]")); val n = JSONArray()
            n.put(JSONObject().put("t", System.currentTimeMillis()).put("p", x.optString("provider")).put("a", x.optDouble("amount", 0.0)).put("x", x.optString("trxId")).put("ok", x.optBoolean("confirmed")))
            for (i in 0 until minOf(a.length(), 19)) n.put(a.get(i))
            p.edit().putString("dayKey", day).putInt("dayCount", cnt).putLong("dayAmt", amt).putString("recent", n.toString()).apply()
            if (p.getBoolean("vibe", true)) buzz(c)
        } catch (_: Exception) {}
    }
    private fun buzz(c: Context) {
        try {
            val v = c.getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            if (android.os.Build.VERSION.SDK_INT >= 26) v.vibrate(android.os.VibrationEffect.createOneShot(220, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(220)
        } catch (_: Exception) {}
    }

    private fun summary(body: String): String = try {
        val r = JSONObject(body).optJSONArray("results"); val x = r?.optJSONObject(0)
        when {
            x == null -> "ok"
            x.optBoolean("ignored") -> "ignored by server: " + x.optString("reason")
            x.optBoolean("duplicate") -> "already received before"
            x.optBoolean("confirmed") -> "${x.optString("provider")} ৳${x.optDouble("amount")} TrxID ${x.optString("trxId")} → order confirmed"
            else -> "${x.optString("provider")} ৳${x.optDouble("amount")} TrxID ${x.optString("trxId")} saved"
        }
    } catch (e: Exception) { body.take(60) }

    private fun post(u: String, k: String, m: JSONObject): Pair<Int, String> = try {
        val con = URL(u).openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.connectTimeout = 15000; con.readTimeout = 25000; con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json"); con.setRequestProperty("X-Api-Key", k)
        con.setRequestProperty("X-Device", android.os.Build.MODEL ?: "android")
        con.outputStream.use { it.write(JSONObject().put("from", m.optString("from")).put("text", m.optString("text")).put("date", m.optLong("at")).toString().toByteArray()) }
        val code = con.responseCode
        val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
        Pair(code, body)
    } catch (e: Exception) { Pair(-1, e.message ?: "network error") }

    fun testConnection(c: Context): String {
        val u = url(c); if (u.isEmpty()) return "Sign in first."
        val t0 = System.currentTimeMillis()
        return try {
            val con = URL(u + (if (u.contains("?")) "&" else "?") + "key=" + java.net.URLEncoder.encode(key(c), "UTF-8") + "&device=" + java.net.URLEncoder.encode(android.os.Build.MODEL ?: "android", "UTF-8")).openConnection() as HttpURLConnection
            con.connectTimeout = 10000; con.readTimeout = 10000
            val code = con.responseCode
            if (code in 200..299) { val ms = System.currentTimeMillis() - t0; prefs(c).edit().putLong("pingMs", ms).putLong("pingAt", System.currentTimeMillis()).apply(); "Connected ✓ key is correct (" + ms + " ms)" } else if (code == 401) "Wrong key. Sign in again." else "Server answered $code"
        } catch (e: Exception) { "Cannot reach the server: " + (e.message ?: "") }
    }

    /** Merchant sign-in: fetches the address and key from the site. The password is not stored. */
    fun login(c: Context, site: String, email: String, password: String): String {
        var base = site.trim().trimEnd('/')
        if (base.isEmpty()) return "Enter the AsiaPay site address."
        if (!base.startsWith("http")) base = "https://$base"
        base = Regex("^(https?://[^/]+).*$").replace(base, "$1")
        return try {
            val con = URL("$base/.netlify/functions/own-pay").openConnection() as HttpURLConnection
            con.requestMethod = "POST"; con.connectTimeout = 15000; con.readTimeout = 25000; con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(JSONObject().put("action", "app_login").put("email", email.trim()).put("password", password).toString().toByteArray()) }
            val code = con.responseCode
            val body = (if (code in 200..299) con.inputStream else con.errorStream)?.bufferedReader()?.readText() ?: ""
            val j = JSONObject(body)
            if (code in 200..299 && j.optBoolean("ok")) {
                prefs(c).edit().putString("site", base).putString("url", j.getString("url")).putString("key", j.getString("key")).apply()
                log(c, "Signed in. Address and key saved."); "OK"
            } else j.optString("message", "Sign-in failed ($code)")
        } catch (e: Exception) { "Cannot reach the site: " + (e.message ?: "") }
    }

    fun schedule(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        js.schedule(JobInfo.Builder(77, ComponentName(c, RetryJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(false)
            .setBackoffCriteria(30000, JobInfo.BACKOFF_POLICY_EXPONENTIAL).setMinimumLatency(20000).build())
    }
    /** Runs every ~15 minutes even if the service was killed: scan inbox + resend queue. */
    fun schedulePeriodic(c: Context) {
        val js = c.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (js.allPendingJobs.any { it.id == 78 }) return
        js.schedule(JobInfo.Builder(78, ComponentName(c, RetryJob::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPersisted(true).setPeriodic(15 * 60 * 1000L).build())
    }
    fun pending(c: Context) = JSONArray(prefs(c).getString("queue", "[]")).length()
}
