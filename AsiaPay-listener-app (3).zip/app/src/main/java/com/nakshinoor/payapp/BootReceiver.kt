package com.nakshinoor.payapp

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.service.notification.NotificationListenerService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try { NotificationListenerService.requestRebind(ComponentName(c, NotifService::class.java)) } catch (_: Exception) {}
        Forwarder.schedulePeriodic(c)
        if (Forwarder.prefs(c).getBoolean("keep", true) && Forwarder.configured(c)) KeepAliveService.start(c)
        if (Forwarder.pending(c) > 0) Forwarder.schedule(c)
    }
}
