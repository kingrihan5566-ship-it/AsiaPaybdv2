package com.nakshinoor.payapp

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService

/**
 * Keeps the app alive in the background (also after you swipe it from recent apps),
 * watches the SMS inbox, resends failed payments, and tells the server the phone is online.
 */
class KeepAliveService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var obs: ContentObserver? = null
    private var beat = 0
    private val loop = object : Runnable {
        override fun run() {
            Forwarder.prefs(applicationContext).edit().putLong("svcAt", System.currentTimeMillis()).apply()
            val n = beat++
            Thread {
                try {
                    SmsScan.auto(applicationContext); Forwarder.flush(applicationContext)
                    if (n % 4 == 0) Forwarder.testConnection(applicationContext)           // heartbeat: dashboard shows "phone online"
                    if (n % 10 == 0) try { NotificationListenerService.requestRebind(ComponentName(applicationContext, NotifService::class.java)) } catch (_: Exception) {}
                } catch (_: Exception) {}
            }.start()
            h.postDelayed(this, 60_000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b = if (Build.VERSION.SDK_INT >= 26) { nm.createNotificationChannel(NotificationChannel("keep", "Payment listener", NotificationManager.IMPORTANCE_LOW)); Notification.Builder(this, "keep") } else Notification.Builder(this)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = b.setContentTitle("Payment listener is running").setContentText("Watching bKash, Nagad, Rocket and bank messages").setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(open).setOngoing(true).build()
        try {
            when {
                Build.VERSION.SDK_INT >= 34 -> startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
                Build.VERSION.SDK_INT >= 29 -> startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
                else -> startForeground(1, n)
            }
        } catch (e: Exception) { Forwarder.log(this, "Keep-alive could not start: " + (e.message ?: "")); stopSelf(); return START_NOT_STICKY }
        Forwarder.prefs(this).edit().putLong("svcAt", System.currentTimeMillis()).apply()
        if (obs == null) {
            obs = object : ContentObserver(h) {
                override fun onChange(selfChange: Boolean) { Thread { try { SmsScan.auto(applicationContext); Forwarder.flush(applicationContext) } catch (_: Exception) {} }.start() }
            }
            try { contentResolver.registerContentObserver(Uri.parse("content://sms"), true, obs!!) } catch (_: Exception) {}
        }
        h.removeCallbacks(loop); h.post(loop)
        return START_STICKY
    }

    /** User swiped the app from recent apps: ask Android to start us again right away. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        restartSoon(this)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        h.removeCallbacks(loop)
        obs?.let { try { contentResolver.unregisterContentObserver(it) } catch (_: Exception) {} }
        if (Forwarder.prefs(this).getBoolean("keep", true) && Forwarder.configured(this)) restartSoon(this)   // killed by the system: come back
        super.onDestroy()
    }

    companion object {
        fun restartSoon(c: Context) {
            try {
                val i = Intent(c, KeepAliveService::class.java)
                val fl = PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                val pi = if (Build.VERSION.SDK_INT >= 26) PendingIntent.getForegroundService(c, 5, i, fl) else PendingIntent.getService(c, 5, i, fl)
                (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 2000, pi)
            } catch (_: Exception) {}
        }
        fun start(c: Context) {
            try { val i = Intent(c, KeepAliveService::class.java); if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) } catch (_: Exception) {}
        }
        fun stop(c: Context) { try { c.stopService(Intent(c, KeepAliveService::class.java)) } catch (_: Exception) {} }
        fun alive(c: Context) = System.currentTimeMillis() - Forwarder.prefs(c).getLong("svcAt", 0) < 150_000
    }
}
