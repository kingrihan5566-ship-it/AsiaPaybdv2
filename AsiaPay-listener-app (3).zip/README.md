# AsiaPay Listener (Android)

The phone app that confirms your customers' payments. It reads the "money received" SMS from bKash, Nagad, Rocket and Upay on the phone that holds your SIM, and sends them to AsiaPay. When the TrxID and amount match a waiting payment, it is confirmed automatically.

## Build the APK (free, no Android Studio)
1. Create a new private GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Repo, then **Actions, then Build APK, then Run workflow**. After about 4 minutes download the `AsiaPayListener-apk` file, unzip it and install `app-release.apk` on the phone.

## Set up the phone
1. Open the app and tap **Sign in**. Use your AsiaPay merchant email and password, and the AsiaPay site address. The app fetches the server address and key by itself. (Or copy them from Dashboard, Listener app, Manual setup.)
2. Allow **SMS** and **Notifications** when asked. On Android 13 or newer, if SMS is blocked, open App info, three dots, **Allow restricted settings**.
3. Turn off battery saving for the app and lock it in the recent apps list, so it keeps running when you swipe it away.
4. Press **Send a test message**. The dashboard, Listener app page shows **Connected**.

The app keeps a notification while it runs and retries messages when the internet is back. Your password is never stored on the phone.

## New in 1.1
- Your AsiaPay logo and colours on the app icon and the home screen.
- **Today** card: how many payments and how much money came in today, plus the last payments with TrxID and status.
- **Vibrate** when a new payment arrives.
- **Pause forwarding** switch, for when you want the app on but silent.
- **Sender filter**: only forward messages from the names you list (for example `bKash, NAGAD`).
- **App lock**: ask for a PIN every time the app opens.
- **Server speed** shown after "Save and test".
- **Share log with support** button.

Note: this version was written and checked by reading the code, but not compiled on a real build. If the GitHub build shows an error, send the error text and it will be fixed.
