package com.nakshinoor.payapp

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One screen, built in code (no extra libraries). */
class MainActivity : Activity() {
    private val BRAND = Color.parseColor("#db2763")
    private val BRAND_D = Color.parseColor("#8f1445")
    private val INK = Color.parseColor("#1f2937")
    private val MUT = Color.parseColor("#6b7280")
    private val GREEN = Color.parseColor("#16a34a")
    private val AMBER = Color.parseColor("#d97706")
    private val RED = Color.parseColor("#dc2626")
    private val LINE = Color.parseColor("#e5e1ea")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private class Row(val dot: TextView, val sub: TextView, val btn: TextView)

    private lateinit var root: LinearLayout
    private lateinit var pill: TextView
    private lateinit var pillSub: TextView
    private lateinit var rConn: Row
    private lateinit var rNotif: Row
    private lateinit var rSms: Row
    private lateinit var rBat: Row
    private lateinit var rKeep: Row
    private lateinit var warnCard: LinearLayout
    private lateinit var connView: LinearLayout
    private lateinit var connSummary: TextView
    private lateinit var site: EditText
    private lateinit var email: EditText
    private lateinit var pass: EditText
    private lateinit var url: EditText
    private lateinit var key: EditText
    private lateinit var paste: EditText
    private lateinit var diag: TextView
    private lateinit var rawBox: LinearLayout
    private lateinit var logBox: LinearLayout
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 2500) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
    private fun bg(f: () -> Unit) = Thread { f() }.start()
    private fun rounded(fill: Int, r: Int, stroke: Int = 0): GradientDrawable = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(1), stroke)
    }
    private fun lp(top: Int = 0, bottom: Int = 0, w: Int = MATCH) = LinearLayout.LayoutParams(w, WRAP).apply { setMargins(0, dp(top), 0, dp(bottom)) }

    private fun pillBtn(label: String, fill: Int, fg: Int, onClick: () -> Unit): TextView {
        val v = TextView(this)
        v.text = label; v.textSize = 13f; v.setTextColor(fg); v.setTypeface(v.typeface, Typeface.BOLD); v.gravity = Gravity.CENTER
        v.background = rounded(fill, 22); v.setPadding(dp(14), dp(9), dp(14), dp(9)); v.isClickable = true
        v.setOnClickListener { onClick() }
        return v
    }
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this); v.text = t; v.textSize = size; v.setTextColor(color); if (bold) v.setTypeface(v.typeface, Typeface.BOLD); return v
    }
    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL
        c.background = rounded(Color.WHITE, 16, LINE); c.setPadding(dp(16), dp(14), dp(16), dp(14))
        c.addView(text(title, 16f, INK, true), lp(0, 6))
        root.addView(c, lp(0, 12).apply { setMargins(dp(14), 0, dp(14), dp(12)) })
        return c
    }
    private fun field(hint: String, v: String, pw: Boolean = false, type: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI): EditText {
        val e = EditText(this); e.hint = hint; e.setText(v); e.setSingleLine(); e.textSize = 15f
        e.inputType = if (pw) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else type
        e.background = rounded(Color.parseColor("#faf8fb"), 10, LINE); e.setPadding(dp(12), dp(10), dp(12), dp(10))
        return e
    }
    private fun row(parent: LinearLayout, title: String, desc: String, action: String, onClick: () -> Unit): Row {
        val w = LinearLayout(this); w.orientation = LinearLayout.HORIZONTAL; w.gravity = Gravity.CENTER_VERTICAL; w.setPadding(0, dp(8), 0, dp(8))
        val dot = text("●", 20f, RED); dot.setPadding(0, 0, dp(10), 0)
        val mid = LinearLayout(this); mid.orientation = LinearLayout.VERTICAL
        mid.addView(text(title, 15f, INK, true))
        val sub = text(desc, 12f, MUT); mid.addView(sub)
        val btn = pillBtn(action, BRAND, Color.WHITE, onClick)
        w.addView(dot); w.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f)); w.addView(btn)
        parent.addView(w)
        return Row(dot, sub, btn)
    }
    private fun setRow(r: Row, ok: Boolean, sub: String, showBtn: Boolean = !ok) {
        r.dot.setTextColor(if (ok) GREEN else RED); r.sub.text = sub; r.btn.visibility = if (showBtn) View.VISIBLE else View.GONE
    }
    private fun hhmm(ms: Long) = if (ms <= 0) "never" else SimpleDateFormat("dd MMM HH:mm", Locale.US).format(Date(ms))

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = BRAND_D
        val p = Forwarder.prefs(this)
        root = LinearLayout(this); root.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this); sv.setBackgroundColor(Color.parseColor("#f4f1f6")); sv.addView(root)

        // ---- header ----
        val head = LinearLayout(this); head.orientation = LinearLayout.VERTICAL; head.setPadding(dp(20), dp(26), dp(20), dp(24))
        head.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BRAND, BRAND_D)).apply { cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat()) }
        head.addView(text("AsiaPay", 13f, Color.parseColor("#ffd6e4"), true))
        head.addView(text("Pay Listener", 26f, Color.WHITE, true))
        pill = text("", 14f, Color.WHITE, true); pill.setPadding(dp(14), dp(8), dp(14), dp(8)); pill.background = rounded(AMBER, 20)
        head.addView(pill, lp(14, 0, WRAP))
        pillSub = text("", 12f, Color.parseColor("#ffe3ed")); head.addView(pillSub, lp(8, 0))
        root.addView(head, lp(0, 14))

        // ---- warning for Android 13+ restricted settings ----
        warnCard = LinearLayout(this); warnCard.orientation = LinearLayout.VERTICAL; warnCard.setPadding(dp(16), dp(14), dp(16), dp(14))
        warnCard.background = rounded(Color.parseColor("#fff4e0"), 14, Color.parseColor("#f3c07a"))
        warnCard.addView(text("Buttons not working or greyed out?", 15f, Color.parseColor("#7c3f00"), true))
        warnCard.addView(text("Android 13 and newer blocks apps installed from a file. Open App info, tap the ⋮ menu at the top right, choose “Allow restricted settings”, then try again.", 13f, Color.parseColor("#7c3f00")), lp(4, 8))
        warnCard.addView(pillBtn("Open App info", AMBER, Color.WHITE) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }, lp(0, 0, WRAP))
        root.addView(warnCard, lp(0, 12).apply { setMargins(dp(14), 0, dp(14), dp(12)) })

        // ---- setup checklist ----
        val setup = card("Setup")
        rConn = row(setup, "Connected to AsiaPay", "Sign in below", "Sign in") { connView.visibility = View.VISIBLE; site.requestFocus() }
        rNotif = row(setup, "Read notifications", "bKash, Nagad, Rocket and bank apps", "Allow") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        rSms = row(setup, "Read SMS", "Receive and read payment messages", "Allow") { askSms() }
        rBat = row(setup, "Never sleep", "Lets the app run all day, even when the screen is off", "Allow") { askBattery() }
        rKeep = row(setup, "Always running", "Stays on after you swipe the app away", "Start") { KeepAliveService.start(this); toast("Starting…") }

        // ---- connection ----
        val conn = card("Connection")
        connSummary = text("", 13f, MUT); conn.addView(connSummary, lp(0, 6))
        connView = LinearLayout(this); connView.orientation = LinearLayout.VERTICAL
        connView.addView(text("Sign in with your AsiaPay merchant email and password. The address and key are filled in for you. Your password is not stored.", 12f, MUT), lp(0, 6))
        site = field("AsiaPay site address", p.getString("site", "https://asia-paybd.netlify.app") ?: ""); connView.addView(site, lp(0, 6))
        email = field("AsiaPay email", p.getString("email", "") ?: "", false, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS); connView.addView(email, lp(0, 6))
        pass = field("AsiaPay password", "", true); connView.addView(pass, lp(0, 8))
        connView.addView(pillBtn("Sign in and connect", BRAND, Color.WHITE) {
            val e = email.text.toString(); p.edit().putString("email", e.trim()).apply(); toast("Signing in…")
            bg { val r = Forwarder.login(this, site.text.toString(), e, pass.text.toString())
                h.post { if (r == "OK") { pass.setText(""); url.setText(Forwarder.url(this)); key.setText(Forwarder.key(this)); toast("Connected ✓"); KeepAliveService.start(this); Forwarder.schedulePeriodic(this); connView.visibility = View.GONE; refresh() } else toast(r) } }
        }, lp(0, 12))
        connView.addView(text("Or enter the address and key yourself (Dashboard → Listener app → Manual setup)", 12f, MUT), lp(0, 6))
        url = field("Server address  https://…/api/pay-app", Forwarder.url(this)); connView.addView(url, lp(0, 6))
        key = field("Secret key", Forwarder.key(this)); connView.addView(key, lp(0, 8))
        connView.addView(pillBtn("Save and test", Color.parseColor("#374151"), Color.WHITE) {
            p.edit().putString("url", url.text.toString().trim()).putString("key", key.text.toString().trim()).apply()
            toast("Testing…"); bg { val r = Forwarder.testConnection(this); h.post { toast(r); refresh() }; Forwarder.flush(this) }
            KeepAliveService.start(this); Forwarder.schedulePeriodic(this)
        }, lp(0, 4))
        conn.addView(connView)
        connView.visibility = if (Forwarder.configured(this)) View.GONE else View.VISIBLE
        conn.addView(pillBtn("Change connection", Color.parseColor("#e5e7eb"), INK) { connView.visibility = if (connView.visibility == View.GONE) View.VISIBLE else View.GONE }, lp(4, 0, WRAP))

        // ---- missed payments ----
        val miss = card("Missed a payment?")
        miss.addView(text("Read your SMS inbox and send every payment message again. The server ignores ones it already has.", 12f, MUT), lp(0, 8))
        val r1 = LinearLayout(this); r1.orientation = LinearLayout.HORIZONTAL
        for ((t, d) in listOf("Today" to 1, "3 days" to 3, "7 days" to 7, "30 days" to 30)) {
            r1.addView(pillBtn(t, BRAND, Color.WHITE) { importInbox(d) }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        miss.addView(r1, lp(0, 10))
        paste = EditText(this); paste.hint = "…or paste one message here"; paste.minLines = 2; paste.textSize = 14f
        paste.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        paste.background = rounded(Color.parseColor("#faf8fb"), 10, LINE); paste.setPadding(dp(12), dp(10), dp(12), dp(10))
        miss.addView(paste, lp(0, 8))
        val r2 = LinearLayout(this); r2.orientation = LinearLayout.HORIZONTAL
        r2.addView(pillBtn("Send message", Color.parseColor("#374151"), Color.WHITE) {
            val t = paste.text.toString().trim(); if (t.isEmpty()) { toast("Paste the message first."); return@pillBtn }
            val ok = Forwarder.enqueue(this, "manual", t, System.currentTimeMillis(), force = true)
            toast(if (ok) "Sending…" else "This does not look like a received-money message."); if (ok) bg { Forwarder.flush(this) }; paste.setText("")
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(0, 0, dp(6), 0) })
        r2.addView(pillBtn("Send test", Color.parseColor("#374151"), Color.WHITE) {
            Forwarder.enqueue(this, "bKash", "You have received Tk 1.00 from 01700000000. Fee Tk 0.00. Balance Tk 1.00. TrxID TEST" + (System.currentTimeMillis() % 100000) + " at 01/01/2026 10:00", System.currentTimeMillis(), force = true)
            bg { Forwarder.flush(this) }
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), 0, 0, 0) })
        miss.addView(r2, lp(0, 8))
        miss.addView(pillBtn("Resend everything waiting", Color.parseColor("#e5e7eb"), INK) { toast("Sending…"); bg { val n = Forwarder.flush(this); h.post { toast(if (n == 0) "All sent ✓" else "$n still waiting") } } }, lp(0, 0, WRAP))

        // ---- what the phone sees ----
        val dg = card("What this phone is seeing")
        diag = text("", 13f, INK); dg.addView(diag, lp(0, 8))
        val sw = Switch(this); sw.text = "Read every message with an amount"; sw.isChecked = p.getBoolean("broad", true)
        sw.setOnCheckedChangeListener { _, on -> p.edit().putBoolean("broad", on).apply() }; dg.addView(sw)
        val sw2 = Switch(this); sw2.text = "Show every message here (to find problems)"; sw2.isChecked = p.getBoolean("debug", false)
        sw2.setOnCheckedChangeListener { _, on -> p.edit().putBoolean("debug", on).apply() }; dg.addView(sw2, lp(6, 0))
        val sw3 = Switch(this); sw3.text = "Keep running in the background"; sw3.isChecked = p.getBoolean("keep", true)
        sw3.setOnCheckedChangeListener { _, on -> p.edit().putBoolean("keep", on).apply(); if (on) KeepAliveService.start(this) else KeepAliveService.stop(this) }; dg.addView(sw3, lp(6, 8))
        rawBox = LinearLayout(this); rawBox.orientation = LinearLayout.VERTICAL; dg.addView(rawBox)

        // ---- brand tips ----
        val tips = card("Keep it alive on your phone")
        tips.addView(text(brandTip(), 13f, INK), lp(0, 8))
        tips.addView(pillBtn("Open App info", Color.parseColor("#374151"), Color.WHITE) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }, lp(0, 0, WRAP))

        // ---- activity ----
        val act = card("Activity")
        logBox = LinearLayout(this); logBox.orientation = LinearLayout.VERTICAL; act.addView(logBox)

        setContentView(sv)
    }

    private fun brandTip(): String {
        val m = (Build.MANUFACTURER ?: "").lowercase(Locale.ROOT)
        val lock = "Open recent apps, then lock this app (pull its card down, or tap its icon and choose Lock) so cleaning never closes it."
        return when {
            m.contains("xiaomi") || m.contains("redmi") || m.contains("poco") -> "Xiaomi / Redmi / Poco:\n1. App info → Autostart → ON\n2. App info → Battery saver → No restrictions\n3. $lock"
            m.contains("samsung") -> "Samsung:\n1. Settings → Battery → Background usage limits → Never sleeping apps → add this app\n2. App info → Battery → Unrestricted\n3. $lock"
            m.contains("oppo") || m.contains("realme") || m.contains("oneplus") -> "Oppo / Realme / OnePlus:\n1. App info → Battery usage → Allow background activity\n2. App info → Auto launch → ON\n3. $lock"
            m.contains("vivo") || m.contains("iqoo") -> "Vivo:\n1. Settings → Battery → Background power consumption → Allow for this app\n2. App info → Autostart → ON\n3. $lock"
            m.contains("huawei") || m.contains("honor") -> "Huawei / Honor:\n1. Settings → Battery → App launch → this app → Manage manually → turn ALL three ON\n2. $lock"
            else -> "1. App info → Battery → Unrestricted (no restrictions)\n2. Allow autostart / background activity if your phone has it\n3. $lock"
        }
    }

    private fun askSms() {
        if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS, Manifest.permission.POST_NOTIFICATIONS), 1)
    }
    private fun askBattery() {
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } }
    }

    private fun importInbox(days: Int) {
        if (!SmsScan.canRead(this)) { toast("Allow SMS first."); askSms(); return }
        if (!Forwarder.configured(this)) { toast("Sign in first."); return }
        toast("Reading your inbox…")
        bg {
            val r = SmsScan.scan(this, System.currentTimeMillis() - days * 86_400_000L, force = true)
            Forwarder.log(this, "Import $days day(s): checked ${r.first} message(s), ${r.second} look like payments")
            val left = Forwarder.flush(this)
            h.post { toast("Checked ${r.first}, found ${r.second} payment message(s)" + (if (left > 0) ", $left waiting to send" else ", all sent ✓")) }
        }
    }

    private fun refresh() {
        val p = Forwarder.prefs(this)
        val listener = (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "").contains(packageName)
        val smsRecv = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val smsRead = SmsScan.canRead(this)
        val bat = Build.VERSION.SDK_INT < 23 || (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
        val alive = KeepAliveService.alive(this)
        val conf = Forwarder.configured(this)
        val up = p.getBoolean("listenerUp", false)

        setRow(rConn, conf, if (conf) "Connected · " + (p.getString("site", "") ?: "").replace("https://", "") else "Sign in below", !conf)
        setRow(rNotif, listener, if (!listener) "Not allowed yet" else if (up) "On and connected" else "Allowed — connecting…")
        setRow(rSms, smsRecv && smsRead, if (smsRecv && smsRead) "Allowed" else "Not allowed yet")
        setRow(rBat, bat, if (bat) "No restrictions" else "The phone may stop the app")
        setRow(rKeep, alive, if (alive) "Running now" else "Not running — tap Start")

        val bad = listOf(conf, listener || (smsRecv && smsRead), bat, alive).count { !it }
        if (bad == 0) { pill.text = "● Running"; pill.background = rounded(GREEN, 20); pillSub.text = "Watching for payments. You can close this screen." }
        else { pill.text = "● Needs attention"; pill.background = rounded(AMBER, 20); pillSub.text = "$bad thing(s) to fix in the Setup list below." }
        connSummary.text = if (conf) "Address: " + Forwarder.url(this) else "Not connected yet."
        warnCard.visibility = if (Build.VERSION.SDK_INT >= 33 && !(listener && smsRecv)) View.VISIBLE else View.GONE

        val nAt = p.getLong("nAt", 0); val sAt = p.getLong("sAt", 0)
        diag.text = "Notifications seen: ${p.getInt("nCount", 0)}  (last: ${hhmm(nAt)}${(p.getString("nPkg", "") ?: "").let { if (it.isEmpty()) "" else " · " + it.substringAfterLast('.') }})\n" +
            "SMS received: ${p.getInt("sCount", 0)}  (last: ${hhmm(sAt)})\n" +
            "Payments sent to server: ${p.getInt("fCount", 0)}  (last: ${hhmm(p.getLong("lastSent", 0))})\n" +
            "Waiting to send: ${Forwarder.pending(this)}"

        rawBox.removeAllViews()
        val raw = JSONArray(p.getString("raw", "[]"))
        if (raw.length() == 0) rawBox.addView(text("No payment-like messages seen yet. Turn on “Show every message” and send yourself an SMS to test.", 12f, MUT))
        for (i in 0 until minOf(raw.length(), 12)) {
            val o = raw.getJSONObject(i); val v = o.optString("v")
            val col = if (v.startsWith("forwarding")) GREEN else if (v.startsWith("skipped")) AMBER else MUT
            val t = text((if (o.optString("s") == "S") "SMS" else "Notification") + " · " + o.optString("f").take(26) + "  " + hhmm(o.optLong("t")) + "\n" + o.optString("x").take(110) + "\n→ " + v, 11f, INK)
            t.setPadding(dp(10), dp(6), dp(8), dp(6)); t.background = rounded(Color.parseColor("#faf8fb"), 8)
            val box = LinearLayout(this); box.orientation = LinearLayout.HORIZONTAL
            val bar = View(this); bar.setBackgroundColor(col)
            box.addView(bar, LinearLayout.LayoutParams(dp(4), MATCH)); box.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            rawBox.addView(box, lp(0, 6))
        }

        logBox.removeAllViews()
        val a = JSONArray(p.getString("log", "[]"))
        if (a.length() == 0) logBox.addView(text("Nothing yet.", 12f, MUT))
        for (i in 0 until minOf(a.length(), 40)) {
            val line = a.getString(i); val l = line.lowercase(Locale.ROOT)
            val col = if (l.contains("sent ok") || l.contains("connected") || l.contains("signed in")) GREEN else if (l.contains("wrong") || l.contains("refused") || l.contains("could not") || l.contains("failed") || l.contains("cannot")) RED else INK
            logBox.addView(text(line, 11f, col).apply { typeface = Typeface.MONOSPACE }, lp(0, 2))
        }
        if (listener) try { NotificationListenerService.requestRebind(ComponentName(this, NotifService::class.java)) } catch (_: Exception) {}
    }

    override fun onResume() {
        super.onResume(); h.post(tick)
        Forwarder.schedulePeriodic(this)
        if (Forwarder.configured(this) && Forwarder.prefs(this).getBoolean("keep", true)) KeepAliveService.start(this)
        bg { try { SmsScan.auto(this) } catch (_: Exception) {}; Forwarder.flush(this) }
    }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
}
